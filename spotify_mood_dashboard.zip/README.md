# Spotify Mood Analytics Dashboard (India) — Prototype
This repository contains a Streamlit prototype that estimates listener "mood" for India using Spotify audio features (valence, energy) and regional playlist proxies.
